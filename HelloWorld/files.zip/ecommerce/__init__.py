print("Ecommerce initialized", __name__)
